package com.example.consultation_booking_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
