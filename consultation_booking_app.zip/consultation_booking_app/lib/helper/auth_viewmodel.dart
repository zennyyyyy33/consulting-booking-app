/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: AuthViewModel page

import 'dart:io';
import 'package:consultation_booking_app/models/admin.dart';
import 'package:consultation_booking_app/models/student.dart';
import 'package:consultation_booking_app/services/auth_service.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthViewModel with ChangeNotifier {
  // Instance of AuthService to handle authentication operations
  final AuthService _authService = AuthService();
  // Firestore instance to access user data collections
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  // FirebaseAuth instance to access current user info
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Sign in user with email and password through AuthService
  Future<User?> signInWithEmailAndPassword(
    String email,
    String password,
  ) async {
    return await _authService.signInWithEmailAndPassword(email, password);
  }

  // Register a new student with given details through AuthService
  Future<User?> registerWithEmailAndPassword(
    String email,
    String password,
    String studentId,
    String contactNumber,
    String studentName,
  ) async {
    return await _authService.registerWithEmailAndPassword(
      email,
      password,
      studentId,
      contactNumber,
      studentName,
    );
  }

  // Register a new admin with given details through AuthService
  Future<User?> registerAdminWithEmailAndPassword(
    String email,
    String password,
    String lecturerName,
  ) async {
    return await _authService.registerAdminWithEmailAndPassword(
      email,
      password,
      lecturerName,
    );
  }

  // Sign out the currently logged-in user
  Future<void> signOut() async {
    return await _authService.signOut();
  }

  // Upload a profile picture and return its URL
  Future<String?> uploadProfilePicture(File imageFile) async {
    return await _authService.uploadProfilePicture(imageFile);
  }

  // Private helper method to determine user role by checking Firestore documents
  Future<String?> _getUserRole(String uid) async {
    final studentDoc = await _firestore.collection('students').doc(uid).get();
    if (studentDoc.exists) return 'student'; // If student document exists

    final adminDoc = await _firestore.collection('admins').doc(uid).get();
    if (adminDoc.exists) return 'admin'; // If admin document exists

    return null; // User role unknown if neither exists
  }

  // Fetch user details based on their role and return corresponding model instance
  Future<dynamic> getUserDetails(String uid) async {
    final role = await _getUserRole(uid);

    if (role == 'admin') {
      final docSnapshot = await _firestore.collection('admins').doc(uid).get();
      return Admin.fromMap(
        docSnapshot.data()!,
        docSnapshot.id,
      ); // Convert Firestore data to Admin model
    } else if (role == 'student') {
      final docSnapshot =
          await _firestore.collection('students').doc(uid).get();
      return Student.fromMap(
        docSnapshot.data()!,
        docSnapshot.id,
      ); // Convert Firestore data to Student model
    }

    return null; // Return null if user not found in either collection
  }

  // Update the profile picture URL for the current user based on their role and notify listeners
  Future<void> updateProfilePictureUrl(String url) async {
    final user = _auth.currentUser;
    if (user != null) {
      final uid = user.uid;
      final role = await _getUserRole(uid);

      if (role == 'admin') {
        await _firestore.collection('admins').doc(uid).update({
          'profilePictureUrl': url,
        });
      } else if (role == 'student') {
        await _firestore.collection('students').doc(uid).update({
          'profilePictureUrl': url,
        });
      }

      notifyListeners(); // Notify UI about profile picture update
    }
  }
}
