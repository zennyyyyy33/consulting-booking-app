/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: BookingViewModel page

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:consultation_booking_app/models/booking.dart';
import 'package:consultation_booking_app/services/firestore_service.dart';
import 'package:flutter/material.dart';

class BookingViewModel with ChangeNotifier {
  // Instance of FirestoreService to handle Firestore-related booking operations
  final FirestoreService _firestoreService = FirestoreService();

  // Create a new booking and notify listeners to update UI
  Future<void> createBooking(Booking booking) async {
    try {
      await _firestoreService.createBooking(booking);
      notifyListeners(); // Notify UI about changes
    } catch (e) {
      rethrow; // Propagate error to caller
    }
  }

  // Get a stream of admins (lecturers) data from Firestore service
  Stream<List<Map<String, dynamic>>> getAdmins() {
    return _firestoreService.getAdmins();
  }

  // Get a stream of bookings for a specific student
  Stream<List<Booking>> getBookingsForStudent(String studentId) {
    return _firestoreService.getBookingsForStudent(studentId);
  }

  // Get a stream of bookings for a specific admin (lecturer)
  Stream<List<Booking>> getBookingsForAdmin(String adminId) {
    return _firestoreService.getBookingsForAdmin(adminId);
  }

  // Update an existing booking and notify listeners for UI update
  Future<void> updateBooking(Booking booking) async {
    try {
      await _firestoreService.updateBooking(booking);
      notifyListeners(); // Notify UI about updated booking
    } catch (e) {
      rethrow; // Propagate error
    }
  }

  // Update only the status field of a booking document in Firestore
  Future<void> updateBookingStatus(String bookingId, String newStatus) async {
    try {
      await FirebaseFirestore.instance
          .collection('bookings')
          .doc(bookingId)
          .update({'status': newStatus});
    } catch (e) {
      debugPrint('Error updating booking status: $e'); // Log error to console
      throw Exception('Failed to update booking status'); // Throw exception
    }
  }

  // Delete a booking and notify listeners for UI update
  Future<void> deleteBooking(String bookingId) async {
    try {
      await _firestoreService.deleteBooking(bookingId);
      notifyListeners(); // Notify UI about deleted booking
    } catch (e) {
      rethrow; // Propagate error
    }
  }
}
