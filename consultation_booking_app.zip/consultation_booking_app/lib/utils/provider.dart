/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: Provide page
import 'package:consultation_booking_app/helper/auth_viewmodel.dart';
import 'package:consultation_booking_app/helper/booking_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// ProviderRepo widget that sets up the providers for the app's state management
class ProviderRepo extends StatelessWidget {
  // The child widget that will have access to the providers
  final Widget child;

  // Constructor requires the child widget
  const ProviderRepo({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    // MultiProvider allows registering multiple providers in the widget tree
    return MultiProvider(
      providers: [
        // Register AuthViewModel as a ChangeNotifierProvider for authentication state
        ChangeNotifierProvider(create: (_) => AuthViewModel()),
        // Register BookingViewModel as a ChangeNotifierProvider for booking management state
        ChangeNotifierProvider(create: (_) => BookingViewModel()),
      ],
      // Pass the child widget so it can access the above providers
      child: child,
    );
  }
}
