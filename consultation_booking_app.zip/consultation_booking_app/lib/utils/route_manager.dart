/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: RouteManager page

import 'package:consultation_booking_app/views/admin_dashboard.dart';
import 'package:consultation_booking_app/views/forgot_password.dart';
import 'package:consultation_booking_app/views/home_screen.dart';
import 'package:consultation_booking_app/views/login_screen.dart';
import 'package:consultation_booking_app/views/profile_screen.dart';
import 'package:consultation_booking_app/views/registration_screen.dart';
import 'package:consultation_booking_app/widgets/loader.dart';
import 'package:flutter/material.dart';

class RouteManager {
  // Define static constants for route names to use throughout the app
  static const String loader = '/';
  static const String loginPage = '/loginPage';
  static const String registerPage = '/registerPage';
  static const String forgotPassword = '/forgotPassword';
  static const String homePage = '/homePage';
  static const String bookingForm = '/bookingForm'; // (Not used in switch)
  static const String profileScreen = '/profileScreen';
  static const String adminDashboard = '/adminDashboard';

  // This method generates routes based on the route name passed in settings
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case loader:
        // Route to a loader screen shown on app startup
        return MaterialPageRoute(
          builder: (context) => const LoginScreenLoader(),
        );
      case loginPage:
        // Route to login screen
        return MaterialPageRoute(builder: (context) => const LoginScreen());

      case registerPage:
        // Route to registration screen
        return MaterialPageRoute(
          builder: (context) => const RegistrationScreen(),
        );

      case forgotPassword:
        // Route to forgot password screen
        return MaterialPageRoute(builder: (context) => ForgotPasswordScreen());

      case homePage:
        // Route to home screen after login
        return MaterialPageRoute(builder: (context) => const HomeScreen());

      case adminDashboard:
        // Route to admin dashboard screen
        return MaterialPageRoute(builder: (context) => const AdminDashboard());

      case profileScreen:
        // Route to user profile screen
        return MaterialPageRoute(builder: (context) => ProfileScreen());

      default:
        // Throws error if route name does not match any case
        throw const FormatException('Route not found! Check routes again!');
    }
  }
}
