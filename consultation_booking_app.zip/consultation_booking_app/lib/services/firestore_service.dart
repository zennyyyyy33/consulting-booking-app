/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: FirestoreService page

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:consultation_booking_app/models/booking.dart';

class FirestoreService {
  // Instance of FirebaseFirestore to interact with Firestore database
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Create a new booking document in the 'bookings' collection using booking ID as document ID
  Future<void> createBooking(Booking booking) async {
    try {
      await _firestore.collection('bookings').doc(booking.id).set({
        'studentId': booking.studentId,
        'studentName': booking.studentName,
        'adminId': booking.adminId,
        'lecturerName': booking.lecturerName,
        'date': booking.date,
        'time': booking.time,
        'topic': booking.topic,
        'notes': booking.notes,
        'status': booking.status,
      });
    } catch (e) {
      // Re-throw any caught exceptions for error handling upstream
      rethrow;
    }
  }

  // Retrieve a stream of all admins (lecturers) as a list of maps with admin details
  Stream<List<Map<String, dynamic>>> getAdmins() {
    return _firestore.collection('admins').snapshots().map((snapshot) {
      return snapshot.docs.map((doc) {
        return {
          'id': doc.id,
          'email': doc['email'],
          'lecturerName': doc['lecturerName'],
          'profilePictureUrl': doc['profilePictureUrl'],
        };
      }).toList();
    });
  }

  // Retrieve a stream of bookings filtered by a specific student ID
  Stream<List<Booking>> getBookingsForStudent(String studentId) {
    return _firestore
        .collection('bookings')
        .where('studentId', isEqualTo: studentId)
        .snapshots()
        .map((snapshot) {
          // Map each document snapshot to a Booking model instance
          return snapshot.docs.map((doc) {
            return Booking(
              id: doc.id,
              studentId: doc['studentId'],
              studentName: doc['studentName'],
              adminId: doc['adminId'],
              lecturerName: doc['lecturerName'],
              date: doc['date'],
              time: doc['time'],
              topic: doc['topic'],
              notes: doc['notes'],
              status: doc['status'],
            );
          }).toList();
        });
  }

  // Retrieve a stream of bookings filtered by a specific admin (lecturer) ID
  Stream<List<Booking>> getBookingsForAdmin(String adminId) {
    return _firestore
        .collection('bookings')
        .where('adminId', isEqualTo: adminId)
        .snapshots()
        .map((snapshot) {
          // Map each document snapshot to a Booking model instance
          return snapshot.docs.map((doc) {
            return Booking(
              id: doc.id,
              studentId: doc['studentId'],
              studentName: doc['studentName'],
              adminId: doc['adminId'],
              lecturerName: doc['lecturerName'],
              date: doc['date'],
              time: doc['time'],
              topic: doc['topic'],
              notes: doc['notes'],
              status: doc['status'],
            );
          }).toList();
        });
  }

  // Update an existing booking document identified by booking ID
  Future<void> updateBooking(Booking booking) async {
    try {
      await _firestore.collection('bookings').doc(booking.id).update({
        'studentId': booking.studentId,
        'studentName': booking.studentName,
        'adminId': booking.adminId,
        'lecturerName': booking.lecturerName,
        'date': booking.date,
        'time': booking.time,
        'topic': booking.topic,
        'notes': booking.notes,
        'status': booking.status,
      });
    } catch (e) {
      // Re-throw exceptions for higher-level handling
      rethrow;
    }
  }

  // Delete a booking document by its ID from the 'bookings' collection
  Future<void> deleteBooking(String bookingId) async {
    try {
      await _firestore.collection('bookings').doc(bookingId).delete();
    } catch (e) {
      // Re-throw exceptions for error handling upstream
      rethrow;
    }
  }
}
