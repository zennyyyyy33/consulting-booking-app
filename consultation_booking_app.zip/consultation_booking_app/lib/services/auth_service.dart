/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: AuthService page

import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'dart:io';

class AuthService {
  // Firebase Authentication instance to handle user sign in, sign up, sign out
  final FirebaseAuth _auth = FirebaseAuth.instance;
  // Firestore instance for database operations related to users
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  // Firebase Storage instance for storing profile pictures
  final firebase_storage.FirebaseStorage _storage =
      firebase_storage.FirebaseStorage.instance;

  // Sign in user with email and password, returns Firebase User or null on failure
  Future<User?> signInWithEmailAndPassword(
    String email,
    String password,
  ) async {
    try {
      UserCredential result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return result.user;
    } catch (e) {
      // Return null if sign in fails
      return null;
    }
  }

  // Register a new student user with email, password, student details and store in Firestore
  Future<User?> registerWithEmailAndPassword(
    String email,
    String password,
    String studentId,
    String contactNumber,
    String studentName,
  ) async {
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      // Save student info in 'students' collection with user UID as document ID
      await _firestore.collection('students').doc(result.user!.uid).set({
        'studentId': studentId,
        'email': email,
        'contactNumber': contactNumber,
        'studentName': studentName,
        'profilePictureUrl': null, // Initially no profile picture
      });
      return result.user;
    } catch (e) {
      // Return null if registration fails
      return null;
    }
  }

  // Register a new admin (lecturer) with email, password, and lecturer name, save in Firestore
  Future<User?> registerAdminWithEmailAndPassword(
    String email,
    String password,
    String lecturerName,
  ) async {
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      // Save admin info in 'admins' collection with user UID as document ID
      await _firestore.collection('admins').doc(result.user!.uid).set({
        'email': email,
        'lecturerName': lecturerName,
        'isAdmin': true, // Flag indicating admin role
        'profilePictureUrl': null, // Initially no profile picture
      });
      return result.user;
    } catch (e) {
      // Return null if registration fails
      return null;
    }
  }

  // Sign out the current user from Firebase Authentication
  Future signOut() async {
    try {
      return await _auth.signOut();
    } catch (e) {
      // Return null if sign out fails
      return null;
    }
  }

  // Upload profile picture to Firebase Storage under 'profile_pictures/{userId}' path
  Future<String?> uploadProfilePicture(File imageFile) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      // Return null if no authenticated user
      if (user == null) {
        return null;
      }

      // Upload image file and get a snapshot of the upload task
      final snapshot = await _storage
          .ref('profile_pictures/${user.uid}')
          .putFile(imageFile);
      // Retrieve the download URL of the uploaded profile picture
      final url = await snapshot.ref.getDownloadURL();
      return url;
    } catch (e) {
      // Return null if upload fails
      return null;
    }
  }

  // Update profile picture URL in Firestore for the specified user and user type (student/admin)
  Future<void> updateProfilePictureUrl(
    String userId,
    String url,
    String userType,
  ) async {
    try {
      if (userType == 'student') {
        // Update the 'profilePictureUrl' field for student document
        await _firestore.collection('students').doc(userId).update({
          'profilePictureUrl': url,
        });
      } else if (userType == 'admin') {
        // Update the 'profilePictureUrl' field for admin document
        await _firestore.collection('admins').doc(userId).update({
          'profilePictureUrl': url,
        });
      }
    } catch (e) {
      // Re-throw exception to handle error upstream
      rethrow;
    }
  }
}
