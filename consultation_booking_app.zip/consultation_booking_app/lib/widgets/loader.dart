import 'package:consultation_booking_app/views/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginScreenLoader extends StatelessWidget {
  const LoginScreenLoader({super.key});

  Future<bool> _initializePreferences() async {
    try {
      await SharedPreferences.getInstance();
      return true;
    } catch (e) {
      debugPrint("Error initializing SharedPreferences: $e");
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: _initializePreferences(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          return LoginScreen();
        } else if (snapshot.hasError || (snapshot.hasData && !snapshot.data!)) {
          return Scaffold(
            body: Center(child: Text('Error loading app preferences')),
          );
        } else {
          return Scaffold(body: Center(child: CircularProgressIndicator()));
        }
      },
    );
  }
}
