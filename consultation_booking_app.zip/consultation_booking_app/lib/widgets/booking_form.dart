import 'package:consultation_booking_app/helper/booking_viewmodel.dart';
import 'package:consultation_booking_app/models/booking.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class BookingForm extends StatefulWidget {
  final Booking? existingBooking;

  const BookingForm({super.key, this.existingBooking});

  @override
  _BookingFormState createState() => _BookingFormState();
}

class _BookingFormState extends State<BookingForm> {
  final _formKey = GlobalKey<FormState>();
  final _topicController = TextEditingController();
  final _notesController = TextEditingController();

  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  String? _selectedAdminId;
  // ignore: unused_field
  String? _selectedLecturerEmail;
  String? _selectedLecturerName;
  String? _studentId;

  @override
  void initState() {
    super.initState();
    _loadStudentData();
    if (widget.existingBooking != null) {
      _selectedDate = DateFormat(
        'yyyy-MM-dd',
      ).parse(widget.existingBooking!.date);
      _selectedTime = _parseTimeString(widget.existingBooking!.time);
      _topicController.text = widget.existingBooking!.topic;
      _notesController.text = widget.existingBooking!.notes ?? '';
      _selectedAdminId = widget.existingBooking!.adminId;
      _selectedLecturerEmail = widget.existingBooking!.lecturerName;
      _selectedLecturerName = widget.existingBooking!.lecturerName;
    }
  }

  Future<void> _loadStudentData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final studentDoc =
          await FirebaseFirestore.instance
              .collection('students')
              .doc(user.uid)
              .get();
      if (studentDoc.exists) {
        setState(() {
          _studentId = studentDoc['studentId'];
        });
      }
    }
  }

  TimeOfDay _parseTimeString(String time) {
    final parts = time.split(":");
    return TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1]));
  }

  @override
  void dispose() {
    _topicController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  InputDecoration _inputDecoration(String label) {
    return InputDecoration(
      labelText: label,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      filled: true,
      fillColor: Colors.white,
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (picked != null) setState(() => _selectedDate = picked);
  }

  Future<void> _selectTime(BuildContext context) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.now(),
    );
    if (picked != null) setState(() => _selectedTime = picked);
  }

  @override
  Widget build(BuildContext context) {
    final bookingViewModel = Provider.of<BookingViewModel>(context);
    final user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.existingBooking == null ? 'Create Booking' : 'Edit Booking',
        ),
        backgroundColor: Colors.blueGrey.shade900,
        centerTitle: true,
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.blueGrey.shade800,
              Colors.grey.shade600,
              Colors.grey.shade400,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 6,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      _buildLecturerDropdown(bookingViewModel),
                      const SizedBox(height: 16),
                      _buildDatePicker(context),
                      const SizedBox(height: 16),
                      _buildTimePicker(context),
                      const SizedBox(height: 16),
                      _buildTopicField(),
                      const SizedBox(height: 16),
                      _buildNotesField(),
                      const SizedBox(height: 24),
                      _buildSaveButton(context, user, bookingViewModel),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLecturerDropdown(BookingViewModel viewModel) {
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: viewModel.getAdmins(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) return Text('Error: ${snapshot.error}');
        if (!snapshot.hasData || snapshot.data!.isEmpty)
          return const Text('No lecturers available');

        final admins = snapshot.data!;
        return DropdownButtonFormField<String>(
          decoration: _inputDecoration('Lecturer'),
          value: _selectedAdminId,
          items:
              admins.map((admin) {
                return DropdownMenuItem<String>(
                  value: admin['id'],
                  child: Text('${admin['lecturerName']} (${admin['email']})'),
                );
              }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedAdminId = value;
              final selected = admins.firstWhere(
                (admin) => admin['id'] == value,
              );
              _selectedLecturerEmail = selected['email'];
              _selectedLecturerName = selected['lecturerName'];
            });
          },
          validator:
              (value) => value == null ? 'Please select a lecturer' : null,
        );
      },
    );
  }

  Widget _buildDatePicker(BuildContext context) {
    return TextFormField(
      readOnly: true,
      decoration: _inputDecoration('Date'),
      controller: TextEditingController(
        text:
            _selectedDate != null
                ? DateFormat('yyyy-MM-dd').format(_selectedDate!)
                : '',
      ),
      onTap: () => _selectDate(context),
      validator: (_) => _selectedDate == null ? 'Please select a date' : null,
    );
  }

  Widget _buildTimePicker(BuildContext context) {
    return TextFormField(
      readOnly: true,
      decoration: _inputDecoration('Time'),
      controller: TextEditingController(
        text:
            _selectedTime != null
                ? '${_selectedTime!.hour.toString().padLeft(2, '0')}:${_selectedTime!.minute.toString().padLeft(2, '0')}'
                : '',
      ),
      onTap: () => _selectTime(context),
      validator: (_) => _selectedTime == null ? 'Please select a time' : null,
    );
  }

  Widget _buildTopicField() {
    return TextFormField(
      controller: _topicController,
      decoration: _inputDecoration('Topic'),
      maxLines: 2,
      validator:
          (value) =>
              (value == null || value.length < 20)
                  ? 'Topic must be at least 20 characters long'
                  : null,
    );
  }

  Widget _buildNotesField() {
    return TextFormField(
      controller: _notesController,
      decoration: _inputDecoration('Additional Notes'),
      maxLines: 3,
    );
  }

  Widget _buildSaveButton(
    BuildContext context,
    User? user,
    BookingViewModel viewModel,
  ) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        icon: const Icon(Icons.save),
        label: const Text('Save Booking'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.blueGrey.shade900,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        onPressed: () async {
          if (_formKey.currentState!.validate()) {
            final booking = Booking(
              id:
                  widget.existingBooking?.id ??
                  DateTime.now().millisecondsSinceEpoch.toString(),
              studentId: _studentId ?? '',
              studentName: user?.displayName ?? '',
              adminId: _selectedAdminId ?? '',
              lecturerName: _selectedLecturerName ?? '',
              date: DateFormat('yyyy-MM-dd').format(_selectedDate!),
              time:
                  '${_selectedTime!.hour.toString().padLeft(2, '0')}:${_selectedTime!.minute.toString().padLeft(2, '0')}',
              topic: _topicController.text.trim(),
              notes: _notesController.text.trim(),
              status: 'pending',
            );

            try {
              if (widget.existingBooking == null) {
                await viewModel.createBooking(booking);
              } else {
                await viewModel.updateBooking(booking);
              }
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Booking saved successfully')),
              );
              Navigator.pop(context);
            } catch (e) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Error saving booking: $e')),
              );
            }
          }
        },
      ),
    );
  }
}
