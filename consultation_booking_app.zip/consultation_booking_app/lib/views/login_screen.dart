/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: Login Screen page

import 'package:consultation_booking_app/helper/auth_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'admin_dashboard.dart';
import 'home_screen.dart';
import 'registration_screen.dart';
import 'forgot_password.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  // Form key to validate login form
  final _formKey = GlobalKey<FormState>();

  // Controllers for input fields
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  // Flags for "Remember Me" and loading spinner
  bool _rememberMe = false;
  bool _isLoading = false;

  // Animation controller and fade effect
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();

    // Initialize fade-in animation
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    // Apply ease-in curve to the animation
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeIn,
    );

    _animationController.forward(); // Start animation

    // Load saved credentials if "Remember Me" is checked
    _loadUserCredentials();
  }

  // Load email and password from shared preferences
  Future<void> _loadUserCredentials() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool? rememberMe = prefs.getBool('remember_me');
    String? email = prefs.getString('email');
    String? password = prefs.getString('password');

    // Populate fields if "Remember Me" was selected
    if (rememberMe ?? false) {
      setState(() {
        _rememberMe = true;
        _emailController.text = email ?? '';
        _passwordController.text = password ?? '';
      });
    }
  }

  // Save or clear credentials based on checkbox
  Future<void> _saveUserCredentials() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (_rememberMe) {
      await prefs.setBool('remember_me', true);
      await prefs.setString('email', _emailController.text.trim());
      await prefs.setString('password', _passwordController.text.trim());
    } else {
      await prefs.remove('remember_me');
      await prefs.remove('email');
      await prefs.remove('password');
    }
  }

  // Handle login and role-based redirection
  Future<void> _login(AuthViewModel authViewModel) async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isLoading = true); // Show loading spinner

      // Authenticate using AuthViewModel
      User? user = await authViewModel.signInWithEmailAndPassword(
        _emailController.text.trim(),
        _passwordController.text.trim(),
      );

      setState(() => _isLoading = false); // Hide loading spinner

      if (user != null) {
        await _saveUserCredentials(); // Save credentials if needed

        // Check if user is an admin
        DocumentSnapshot adminDoc =
            await FirebaseFirestore.instance
                .collection('admins')
                .doc(user.uid)
                .get();

        // Navigate based on user role
        if (adminDoc.exists && adminDoc['isAdmin'] == true) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const AdminDashboard()),
          );
        } else {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const HomeScreen()),
          );
        }
      } else {
        // Show error if login fails
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('Login failed')));
      }
    }
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authViewModel = Provider.of<AuthViewModel>(context);

    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.blueGrey.shade800,
              Colors.grey.shade600,
              Colors.grey.shade400,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 50),
                _buildHeader(), // Title and subtitle
                const SizedBox(height: 30),
                _buildLoginForm(authViewModel), // Form with fields and buttons
                const SizedBox(height: 20),
                _buildRegisterText(), // Registration prompt
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Title and subtitle for welcome message
  Widget _buildHeader() {
    return Column(
      children: [
        Text(
          'Welcome to ConsultBook',
          style: GoogleFonts.montserrat(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.white,
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'Please login to your account',
          style: GoogleFonts.roboto(fontSize: 16, color: Colors.white70),
        ),
      ],
    );
  }

  // Login form with animation
  Widget _buildLoginForm(AuthViewModel authViewModel) {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              _buildEmailField(), // Email input
              const SizedBox(height: 16),
              _buildPasswordField(), // Password input
              const SizedBox(height: 12),
              _buildRememberMeAndForgotPassword(), // Remember me + forgot password
              const SizedBox(height: 20),
              _buildLoginButton(authViewModel), // Login button
            ],
          ),
        ),
      ),
    );
  }

  // Email input field with validation
  Widget _buildEmailField() {
    return TextFormField(
      controller: _emailController,
      decoration: InputDecoration(
        labelText: 'Email',
        prefixIcon: const Icon(Icons.email_outlined),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        filled: true,
        fillColor: Colors.grey[200],
      ),
      validator: (value) {
        if (value == null || !value.contains('@')) {
          return 'Enter a valid email';
        }
        return null;
      },
    );
  }

  // Password input field with validation
  Widget _buildPasswordField() {
    return TextFormField(
      controller: _passwordController,
      obscureText: true,
      decoration: InputDecoration(
        labelText: 'Password',
        prefixIcon: const Icon(Icons.lock_outline),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        filled: true,
        fillColor: Colors.grey[200],
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Enter your password';
        }
        return null;
      },
    );
  }

  // "Remember Me" checkbox and forgot password link
  Widget _buildRememberMeAndForgotPassword() {
    return Row(
      children: [
        Checkbox(
          value: _rememberMe,
          onChanged: (value) {
            setState(() => _rememberMe = value!);
          },
        ),
        Text('Remember me', style: GoogleFonts.roboto(color: Colors.white)),
        const Spacer(),
        TextButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ForgotPasswordScreen()),
            );
          },
          child: Text(
            'Forgot Password?',
            style: GoogleFonts.roboto(color: Colors.white),
          ),
        ),
      ],
    );
  }

  // Login button with loading spinner
  Widget _buildLoginButton(AuthViewModel authViewModel) {
    return _isLoading
        ? const CircularProgressIndicator()
        : ElevatedButton.icon(
          icon: const Icon(Icons.login),
          label: const Text('Login'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blueGrey.shade800,
            foregroundColor: Colors.white,
            minimumSize: const Size(double.infinity, 50),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          onPressed: () => _login(authViewModel),
        );
  }

  // Text and link to register screen
  Widget _buildRegisterText() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          "Don't have an account yet? ",
          style: GoogleFonts.roboto(color: Colors.white70),
        ),
        GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const RegistrationScreen()),
            );
          },
          child: Text(
            'Register',
            style: GoogleFonts.roboto(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }
}
