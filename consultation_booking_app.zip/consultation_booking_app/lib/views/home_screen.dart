// ignore_for_file: library_private_types_in_public_api, use_build_context_synchronously, deprecated_member_use

/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: HomeScreen page

import 'package:consultation_booking_app/helper/auth_viewmodel.dart';
import 'package:consultation_booking_app/helper/booking_viewmodel.dart';
import 'package:consultation_booking_app/models/booking.dart';
import 'package:consultation_booking_app/utils/route_manager.dart';
import 'package:consultation_booking_app/widgets/booking_form.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _studentId = ''; // Stores the current logged-in student's ID

  @override
  void initState() {
    super.initState();
    _loadStudentId(); // Loads the student ID on screen initialization
  }

  // Fetches the studentId from Firestore for the current user
  Future<void> _loadStudentId() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final studentDoc =
          await FirebaseFirestore.instance
              .collection('students')
              .doc(user.uid)
              .get();
      if (studentDoc.exists) {
        setState(() {
          _studentId =
              studentDoc['studentId'] ??
              ''; // Assign student ID to local variable
        });
      }
    }
  }

  // Shows confirmation dialog before deleting a booking
  Future<bool> _confirmDelete(BuildContext context) async {
    return await showDialog<bool>(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Confirm Deletion'),
              content: const Text(
                'Are you sure you want to delete this booking?',
              ),
              actions: <Widget>[
                TextButton(
                  child: const Text('Cancel'),
                  onPressed:
                      () => Navigator.of(
                        context,
                      ).pop(false), // Return false if canceled
                ),
                TextButton(
                  child: const Text('Delete'),
                  onPressed:
                      () => Navigator.of(
                        context,
                      ).pop(true), // Return true if confirmed
                ),
              ],
            );
          },
        ) ??
        false;
  }

  // Displays booking details in a popup dialog
  void _showBookingDetails(BuildContext context, Booking booking) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Booking Details'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('Topic: ${booking.topic}'),
                Text('Date: ${booking.date}'),
                Text('Time: ${booking.time}'),
                Text('Student ID: ${booking.studentId}'),
                Text('Lecturer: ${booking.lecturerName}'),
                Text('Status: ${booking.status}'),
                if (booking.notes != null && booking.notes!.isNotEmpty)
                  Text('Notes: ${booking.notes}'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Close'),
              onPressed: () => Navigator.of(context).pop(), // Closes the dialog
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final authViewModel = Provider.of<AuthViewModel>(context);
    final bookingViewModel = Provider.of<BookingViewModel>(context);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.blueGrey.shade900.withOpacity(0.9),
        elevation: 0,
        title: const Text(
          'My Bookings',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
            color: Colors.white,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.person, color: Colors.white),
          onPressed: () {
            Navigator.pushNamed(
              context,
              RouteManager.profileScreen,
            ); // Navigates to profile
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.white),
            onPressed: () async {
              await authViewModel.signOut(); // Logs out user
              Navigator.pushReplacementNamed(
                context,
                RouteManager.loginPage,
              ); // Redirect to login
            },
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.blueGrey.shade800,
              Colors.grey.shade700,
              Colors.grey.shade600,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: StreamBuilder<List<Booking>>(
          stream: bookingViewModel.getBookingsForStudent(
            _studentId,
          ), // Fetches bookings for the student
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(
                  color: Colors.white,
                ), // Loading spinner
              );
            }
            if (snapshot.hasError) {
              return const Center(
                child: Text(
                  'Error loading bookings',
                  style: TextStyle(color: Colors.white),
                ),
              );
            }
            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.calendar_today,
                      size: 60,
                      color: Colors.white.withOpacity(0.7),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'No Bookings Available',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.7),
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              );
            }

            final bookings = snapshot.data!; // List of bookings from the stream
            return ListView.builder(
              padding: const EdgeInsets.only(
                top: 90,
                left: 16,
                right: 16,
                bottom: 80,
              ),
              itemCount: bookings.length,
              itemBuilder: (context, index) {
                final booking = bookings[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Slidable(
                    key: ValueKey(
                      booking.id,
                    ), // Unique key for each booking item
                    endActionPane: ActionPane(
                      motion: const DrawerMotion(),
                      children: [
                        SlidableAction(
                          onPressed: (_) {
                            // Navigate to edit booking screen
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder:
                                    (_) =>
                                        BookingForm(existingBooking: booking),
                              ),
                            );
                          },
                          backgroundColor: Colors.blueGrey.shade600,
                          foregroundColor: Colors.white,
                          icon: Icons.edit,
                          label: 'Edit',
                        ),
                        SlidableAction(
                          onPressed: (_) async {
                            final confirm = await _confirmDelete(
                              context,
                            ); // Confirm before delete
                            if (confirm) {
                              await bookingViewModel.deleteBooking(
                                booking.id,
                              ); // Delete booking
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Booking deleted'),
                                ),
                              );
                            }
                          },
                          backgroundColor: Colors.red.shade700,
                          foregroundColor: Colors.white,
                          icon: Icons.delete,
                          label: 'Delete',
                        ),
                      ],
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.blueGrey.shade900.withOpacity(0.85),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black26,
                            blurRadius: 6,
                            offset: const Offset(2, 2),
                          ),
                        ],
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                        leading: const Icon(
                          Icons.calendar_today,
                          color: Colors.white,
                        ),
                        title: Text(
                          booking.topic,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${booking.date} • ${booking.time}',
                              style: TextStyle(color: Colors.grey.shade300),
                            ),
                            Text(
                              'Status: ${booking.status}',
                              style: TextStyle(color: Colors.grey.shade300),
                            ),
                          ],
                        ),
                        onTap:
                            () => _showBookingDetails(
                              context,
                              booking,
                            ), // Show booking info
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Colors.blueGrey.shade800,
        foregroundColor: Colors.white,
        onPressed: () {
          // Navigate to booking form to create a new booking
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const BookingForm()),
          );
        },
        icon: const Icon(Icons.add),
        label: const Text("New Booking"),
      ),
    );
  }
}
