/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: Admin Dashboard

import 'package:consultation_booking_app/helper/auth_viewmodel.dart';
import 'package:consultation_booking_app/helper/booking_viewmodel.dart';
import 'package:consultation_booking_app/models/booking.dart';
import 'package:consultation_booking_app/utils/route_manager.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_fonts/google_fonts.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final TextEditingController _searchController =
      TextEditingController(); // Controller for search input
  DateTime? _startDate; // Start date for date filter
  DateTime? _endDate; // End date for date filter

  @override
  Widget build(BuildContext context) {
    final authViewModel = Provider.of<AuthViewModel>(
      context,
    ); // Authentication logic
    final bookingViewModel = Provider.of<BookingViewModel>(
      context,
    ); // Booking data logic
    final user = FirebaseAuth.instance.currentUser; // Currently logged-in user

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Admin Dashboard',
          style: GoogleFonts.montserrat(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.blueGrey.shade800, // App bar color
        elevation: 4,
        actions: [
          // Logout button
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.white),
            onPressed: () async {
              await authViewModel.signOut(); // Sign out
              Navigator.pushReplacementNamed(
                context,
                RouteManager.loginPage,
              ); // Redirect to login
            },
          ),
        ],
        leading: IconButton(
          // Profile icon
          icon: const Icon(Icons.person, color: Colors.white),
          onPressed: () {
            Navigator.pushNamed(
              context,
              RouteManager.profileScreen,
            ); // Navigate to profile
          },
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          // Background gradient
          gradient: LinearGradient(
            colors: [
              Colors.blueGrey.shade800,
              Colors.grey.shade600,
              Colors.grey.shade400,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          children: [
            // Filter/Search UI
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  // Text field for student ID search
                  TextField(
                    controller: _searchController,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      labelText: 'Search by Student ID',
                      labelStyle: const TextStyle(color: Colors.white70),
                      prefixIcon: const Icon(Icons.search, color: Colors.white),
                      filled: true,
                      fillColor: Colors.black.withOpacity(0.2),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onChanged: (_) => setState(() {}), // Trigger search
                  ),
                  const SizedBox(height: 12),
                  // Date range pickers
                  Row(
                    children: [
                      // Start date picker
                      Expanded(
                        child: OutlinedButton.icon(
                          icon: const Icon(
                            Icons.date_range,
                            color: Colors.white,
                          ),
                          label: Text(
                            _startDate == null
                                ? 'Start Date'
                                : _formatDate(_startDate),
                            style: const TextStyle(color: Colors.white),
                          ),
                          onPressed: () => _pickDate(context, true),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: Colors.white),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      // End date picker
                      Expanded(
                        child: OutlinedButton.icon(
                          icon: const Icon(
                            Icons.date_range,
                            color: Colors.white,
                          ),
                          label: Text(
                            _endDate == null
                                ? 'End Date'
                                : _formatDate(_endDate),
                            style: const TextStyle(color: Colors.white),
                          ),
                          onPressed: () => _pickDate(context, false),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                  // Clear filters button
                  if (_searchController.text.isNotEmpty ||
                      _startDate != null ||
                      _endDate != null)
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton.icon(
                        icon: const Icon(Icons.clear, color: Colors.white),
                        label: const Text(
                          'Clear Filters',
                          style: TextStyle(color: Colors.white),
                        ),
                        onPressed: () {
                          setState(() {
                            _searchController.clear();
                            _startDate = null;
                            _endDate = null;
                          });
                        },
                      ),
                    ),
                ],
              ),
            ),
            // Booking list
            Expanded(
              child: StreamBuilder<List<Booking>>(
                stream: bookingViewModel.getBookingsForAdmin(user?.uid ?? ''),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: CircularProgressIndicator(color: Colors.white),
                    );
                  }

                  if (snapshot.hasError) {
                    return Center(
                      child: Text(
                        'Error: ${snapshot.error}',
                        style: const TextStyle(color: Colors.red),
                      ),
                    );
                  }

                  if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return const Center(
                      child: Text(
                        'No bookings found',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    );
                  }

                  List<Booking> bookings = snapshot.data!;

                  // Filter by student ID
                  if (_searchController.text.isNotEmpty) {
                    bookings =
                        bookings
                            .where(
                              (b) => b.studentId.toLowerCase().contains(
                                _searchController.text.toLowerCase(),
                              ),
                            )
                            .toList();
                  }

                  // Filter by date range
                  if (_startDate != null && _endDate != null) {
                    bookings =
                        bookings.where((b) {
                          final bookingDate = DateTime.tryParse(b.date);
                          return bookingDate != null &&
                              bookingDate.isAfter(
                                _startDate!.subtract(const Duration(days: 1)),
                              ) &&
                              bookingDate.isBefore(
                                _endDate!.add(const Duration(days: 1)),
                              );
                        }).toList();
                  }

                  return ListView.separated(
                    itemCount: bookings.length,
                    padding: const EdgeInsets.all(12),
                    separatorBuilder:
                        (_, __) => Divider(
                          color: Colors.white.withOpacity(0.3),
                          thickness: 1,
                        ),
                    itemBuilder: (context, index) {
                      final booking = bookings[index];
                      return Slidable(
                        key: ValueKey(booking.id),
                        endActionPane: ActionPane(
                          motion: const DrawerMotion(),
                          children: [
                            // Delete booking action
                            SlidableAction(
                              onPressed:
                                  (_) => _confirmDelete(
                                    context,
                                    booking,
                                    bookingViewModel,
                                  ),
                              backgroundColor: Colors.redAccent,
                              foregroundColor: Colors.white,
                              icon: Icons.delete,
                              label: 'Delete',
                            ),
                          ],
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.95),
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 6,
                                offset: Offset(2, 2),
                              ),
                            ],
                          ),
                          child: ListTile(
                            onTap:
                                () => _showBookingDetailsDialog(
                                  context,
                                  booking,
                                  bookingViewModel,
                                ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            leading: const Icon(
                              Icons.calendar_today,
                              color: Color(0xFF2575FC),
                            ),
                            title: Text(
                              booking.topic,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            subtitle: Text(
                              '${booking.studentName} (${booking.studentId})\n${booking.lecturerName} • ${booking.date} at ${booking.time}',
                              style: TextStyle(color: Colors.grey[700]),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Dialog to confirm deletion of a booking
  void _confirmDelete(
    BuildContext context,
    Booking booking,
    BookingViewModel viewModel,
  ) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder:
          (ctx) => AlertDialog(
            title: const Text('Confirm Deletion'),
            content: const Text(
              'Are you sure you want to delete this booking?',
            ),
            actions: [
              TextButton(
                child: const Text('Cancel'),
                onPressed: () => Navigator.pop(ctx, false),
              ),
              ElevatedButton(
                child: const Text('Delete'),
                onPressed: () => Navigator.pop(ctx, true),
              ),
            ],
          ),
    );

    if (confirm == true) {
      await viewModel.deleteBooking(booking.id); // Perform deletion
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Booking deleted successfully')),
        );
      }
    }
  }

  // Dialog showing detailed booking information
  void _showBookingDetailsDialog(
    BuildContext context,
    Booking booking,
    BookingViewModel viewModel,
  ) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Booking Details'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Student Name: ${booking.studentName}'),
                Text('Student ID: ${booking.studentId}'),
                Text('Lecturer: ${booking.lecturerName}'),
                Text('Date: ${booking.date}'),
                Text('Time: ${booking.time}'),
                Text('Topic: ${booking.topic}'),
                if (booking.notes?.isNotEmpty ?? false)
                  Text('Notes: ${booking.notes}'),
                Text('Status: ${booking.status}'),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Close'),
              ),
              if (booking.status.toLowerCase() == 'pending')
                ElevatedButton(
                  onPressed: () async {
                    await viewModel.updateBookingStatus(
                      booking.id,
                      'Confirmed',
                    ); // Confirm booking
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Booking confirmed successfully'),
                      ),
                    );
                  },
                  child: const Text('Confirm Booking'),
                ),
            ],
          ),
    );
  }

  // Helper function to pick dates
  Future<void> _pickDate(BuildContext context, bool isStartDate) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2023),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        if (isStartDate) {
          _startDate = picked;
        } else {
          _endDate = picked;
        }
      });
    }
  }

  // Formats date into YYYY-MM-DD format
  String _formatDate(DateTime? date) {
    if (date == null) return '';
    return date.toLocal().toString().split(' ')[0];
  }
}
