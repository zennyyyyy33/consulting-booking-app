/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: registration_screen page

import 'package:consultation_booking_app/helper/auth_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'login_screen.dart';

// Stateful widget for the registration screen
class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen>
    with SingleTickerProviderStateMixin {
  // Form key to validate the registration form
  final _formKey = GlobalKey<FormState>();

  // Controllers for handling input fields
  final _studentIdController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _contactNumberController = TextEditingController();
  final _nameController = TextEditingController();

  // Variables to manage state
  bool _isAdmin = false;
  bool _isLoading = false;

  // Animation controller for fade-in effect
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    // Initialize the animation controller
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeIn,
    );
    _animationController.forward(); // Start the animation
  }

  @override
  void dispose() {
    // Dispose controllers and animation when screen is removed
    _studentIdController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _contactNumberController.dispose();
    _nameController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  // Method to handle user registration (student or admin)
  Future<void> _register(AuthViewModel authViewModel) async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isLoading = true);

      User? user;

      // Register based on admin or student selection
      if (_isAdmin) {
        user = await authViewModel.registerAdminWithEmailAndPassword(
          _emailController.text.trim(),
          _passwordController.text.trim(),
          _nameController.text.trim(),
        );
      } else {
        user = await authViewModel.registerWithEmailAndPassword(
          _emailController.text.trim(),
          _passwordController.text.trim(),
          _studentIdController.text.trim(),
          _contactNumberController.text.trim(),
          _nameController.text.trim(),
        );
      }

      setState(() => _isLoading = false);

      // Display success or failure message
      if (user != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '${_isAdmin ? "Admin" : "Student"} registered successfully!',
            ),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 3),
          ),
        );

        await Future.delayed(const Duration(seconds: 3));

        // Navigate to login screen
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const LoginScreen()),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '${_isAdmin ? "Admin" : "Student"} registration failed',
            ),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // Access the AuthViewModel using Provider
    final authViewModel = Provider.of<AuthViewModel>(context);

    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          // Gradient background
          gradient: LinearGradient(
            colors: [
              Colors.blueGrey.shade800,
              Colors.grey.shade600,
              Colors.grey.shade400,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 50),
                _buildHeader(), // Title and description
                const SizedBox(height: 30),
                _buildRegistrationForm(authViewModel), // Registration form
                const SizedBox(height: 20),
                _buildLoginText(), // Prompt to login if user already has an account
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Header widget with title and subtitle
  Widget _buildHeader() {
    return Column(
      children: [
        Text(
          'Create an Account',
          style: GoogleFonts.montserrat(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.white,
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'Please fill in the details to register',
          style: GoogleFonts.roboto(fontSize: 16, color: Colors.white70),
        ),
      ],
    );
  }

  // Widget to build the main registration form
  Widget _buildRegistrationForm(AuthViewModel authViewModel) {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.grey.shade800, // Form container color
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                spreadRadius: 2,
                blurRadius: 5,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  // Toggle switch for admin or student registration
                  SwitchListTile(
                    title: Text(
                      'Register as Admin',
                      style: GoogleFonts.roboto(color: Colors.white),
                    ),
                    value: _isAdmin,
                    onChanged: (value) {
                      setState(() => _isAdmin = value);
                    },
                  ),
                  // Name input field
                  TextFormField(
                    controller: _nameController,
                    decoration: _inputDecoration(
                      _isAdmin ? 'Lecturer Name' : 'Student Name',
                      Icons.person,
                    ),
                    style: GoogleFonts.roboto(color: Colors.white),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return _isAdmin
                            ? 'Enter lecturer name'
                            : 'Enter student name';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  // Student ID field (only visible to students)
                  if (!_isAdmin) ...[
                    TextFormField(
                      controller: _studentIdController,
                      decoration: _inputDecoration('Student ID', Icons.badge),
                      style: GoogleFonts.roboto(color: Colors.white),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Enter your student ID';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                  ],
                  // Email field with domain validation
                  TextFormField(
                    controller: _emailController,
                    decoration: _inputDecoration('Email', Icons.email),
                    style: GoogleFonts.roboto(color: Colors.white),
                    validator: (value) {
                      if (value == null ||
                          value.isEmpty ||
                          !value.contains('@')) {
                        return 'Enter a valid email';
                      }
                      final emailDomain = value.split('@').last;
                      if (_isAdmin && emailDomain != 'cut.ac.za') {
                        return 'Admin email must be from @cut.ac.za domain';
                      } else if (!_isAdmin && emailDomain != 'stud.cut.ac.za') {
                        return 'Student email must be from @stud.cut.ac.za domain';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  // Password field
                  TextFormField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: _inputDecoration('Password', Icons.lock),
                    style: GoogleFonts.roboto(color: Colors.white),
                    validator: (value) {
                      if (value == null ||
                          value.length < 8 ||
                          !value.contains('@')) {
                        return 'Password must be at least 8 characters & contain "@"';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  // Confirm password field
                  TextFormField(
                    controller: _confirmPasswordController,
                    obscureText: true,
                    decoration: _inputDecoration(
                      'Confirm Password',
                      Icons.lock,
                    ),
                    style: GoogleFonts.roboto(color: Colors.white),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Confirm your password';
                      }
                      if (value != _passwordController.text) {
                        return 'Passwords do not match';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  // Contact number field (students only)
                  if (!_isAdmin)
                    TextFormField(
                      controller: _contactNumberController,
                      decoration: _inputDecoration(
                        'Contact Number',
                        Icons.phone,
                      ),
                      style: GoogleFonts.roboto(color: Colors.white),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Enter your contact number';
                        }
                        return null;
                      },
                    ),
                  const SizedBox(height: 24),
                  // Show loading indicator or register button
                  _isLoading
                      ? const CircularProgressIndicator()
                      : ElevatedButton.icon(
                        icon: const Icon(Icons.check_circle),
                        label: const Text('Register'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blueGrey.shade800,
                          foregroundColor: Colors.white,
                          minimumSize: const Size(double.infinity, 50),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        onPressed: () => _register(authViewModel),
                      ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Input decoration used by form fields
  InputDecoration _inputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      labelStyle: GoogleFonts.roboto(color: Colors.white70),
      prefixIcon: Icon(icon, color: Colors.white),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      filled: true,
      fillColor: Colors.grey.shade700,
    );
  }

  // Widget prompting user to login if already registered
  Widget _buildLoginText() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          "Already have an account? ",
          style: GoogleFonts.roboto(color: Colors.white70),
        ),
        GestureDetector(
          onTap: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const LoginScreen()),
            );
          },
          child: Text(
            'Login',
            style: GoogleFonts.roboto(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }
}
