/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: Profile Screen page

import 'dart:io';
import 'package:consultation_booking_app/helper/auth_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';

/// ProfileScreen is a StatefulWidget that displays and allows editing of user profile info.
class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  // Controllers for text fields
  final _formKey = GlobalKey<FormState>();
  final _studentIdController = TextEditingController();
  final _emailController = TextEditingController();
  final _contactNumberController = TextEditingController();
  final _nameController = TextEditingController();

  bool _editMode = false; // Toggles edit/view mode
  String? _profilePictureUrl; // Stores profile picture URL
  String? _role; // Determines if user is 'admin' or 'student'

  @override
  void initState() {
    super.initState();
    _loadProfileData(); // Load user profile data on initialization
  }

  /// Fetches the profile data from Firebase for current user.
  Future<void> _loadProfileData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      // Check if the user is an admin
      final adminDoc =
          await FirebaseFirestore.instance
              .collection('admins')
              .doc(user.uid)
              .get();

      // Check if the user is a student
      final studentDoc =
          await FirebaseFirestore.instance
              .collection('students')
              .doc(user.uid)
              .get();

      // Populate fields based on user role
      if (adminDoc.exists) {
        setState(() {
          _role = 'admin';
          _emailController.text = adminDoc['email'] ?? '';
          _nameController.text = adminDoc['lecturerName'] ?? '';
          _profilePictureUrl = adminDoc['profilePictureUrl'];
        });
      } else if (studentDoc.exists) {
        setState(() {
          _role = 'student';
          _studentIdController.text = studentDoc['studentId'] ?? '';
          _emailController.text = studentDoc['email'] ?? '';
          _nameController.text = studentDoc['studentName'] ?? '';
          _contactNumberController.text = studentDoc['contactNumber'] ?? '';
          _profilePictureUrl = studentDoc['profilePictureUrl'];
        });
      }
    }
  }

  /// Opens image picker and uploads selected profile image to Firebase.
  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      final file = File(pickedFile.path);
      final user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        final authViewModel = Provider.of<AuthViewModel>(
          context,
          listen: false,
        );
        final url = await authViewModel.uploadProfilePicture(file);

        if (url != null) {
          setState(() {
            _profilePictureUrl = url;
          });
          await authViewModel.updateProfilePictureUrl(url);
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Background with gradient color
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.blueGrey.shade900,
              Colors.blueGrey.shade700,
              Colors.grey.shade600,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // AppBar with title and edit/save button
              AppBar(
                centerTitle: true,
                backgroundColor: Colors.transparent,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(
                    bottom: Radius.circular(20),
                  ),
                ),
                title: const Text(
                  'My Profile',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Colors.white,
                  ),
                ),
                actions: [
                  // Toggle edit mode and save changes
                  IconButton(
                    icon: Icon(
                      _editMode ? Icons.save : Icons.edit,
                      color: Colors.white,
                    ),
                    tooltip: _editMode ? 'Save' : 'Edit',
                    onPressed: () async {
                      if (_editMode) {
                        if (_formKey.currentState!.validate()) {
                          final user = FirebaseAuth.instance.currentUser;
                          if (user != null && _role != null) {
                            final collection =
                                _role == 'admin' ? 'admins' : 'students';

                            final updateData = {
                              'email': _emailController.text,
                              'profilePictureUrl': _profilePictureUrl,
                            };

                            // Update fields based on role
                            if (_role == 'admin') {
                              updateData['lecturerName'] = _nameController.text;
                            } else {
                              updateData['studentName'] = _nameController.text;
                              updateData['studentId'] =
                                  _studentIdController.text;
                              updateData['contactNumber'] =
                                  _contactNumberController.text;
                            }

                            // Save to Firestore
                            await FirebaseFirestore.instance
                                .collection(collection)
                                .doc(user.uid)
                                .update(updateData);

                            if (!mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Profile updated successfully'),
                              ),
                            );
                          }
                        }
                      }
                      setState(() => _editMode = !_editMode);
                    },
                  ),
                ],
              ),

              // Form with profile fields
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        // Profile picture with tap to change in edit mode
                        GestureDetector(
                          onTap: _editMode ? _pickImage : null,
                          child: Container(
                            padding: const EdgeInsets.all(3),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient:
                                  _editMode
                                      ? LinearGradient(
                                        colors: [
                                          Colors.blue.shade400,
                                          Colors.blue.shade800,
                                        ],
                                      )
                                      : null,
                            ),
                            child: CircleAvatar(
                              radius: 50,
                              backgroundColor: Colors.grey.shade300,
                              backgroundImage:
                                  _profilePictureUrl != null
                                      ? NetworkImage(_profilePictureUrl!)
                                      : null,
                              child:
                                  _profilePictureUrl == null
                                      ? const Icon(
                                        Icons.person,
                                        size: 50,
                                        color: Colors.grey,
                                      )
                                      : null,
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),

                        // Name input
                        _buildProfileField(
                          label:
                              _role == 'admin'
                                  ? 'Lecturer Name'
                                  : 'Student Name',
                          controller: _nameController,
                          enabled: _editMode,
                          validator:
                              (value) =>
                                  value == null || value.isEmpty
                                      ? 'Please enter your name'
                                      : null,
                        ),
                        const SizedBox(height: 16),

                        // Student ID input (visible only for students)
                        if (_role == 'student') ...[
                          _buildProfileField(
                            label: 'Student ID',
                            controller: _studentIdController,
                            enabled: _editMode,
                            validator:
                                (value) =>
                                    value == null || value.isEmpty
                                        ? 'Please enter your Student ID'
                                        : null,
                          ),
                          const SizedBox(height: 16),
                        ],

                        // Email input
                        _buildProfileField(
                          label: 'Email',
                          controller: _emailController,
                          enabled: _editMode,
                          validator:
                              (value) =>
                                  value == null ||
                                          value.isEmpty ||
                                          !value.contains('@')
                                      ? 'Enter a valid email'
                                      : null,
                        ),
                        const SizedBox(height: 16),

                        // Contact number input (students only)
                        if (_role == 'student') ...[
                          _buildProfileField(
                            label: 'Contact Number',
                            controller: _contactNumberController,
                            enabled: _editMode,
                            validator:
                                (value) =>
                                    value == null || value.isEmpty
                                        ? 'Please enter your contact number'
                                        : null,
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Builds a styled TextFormField for profile data
  Widget _buildProfileField({
    required String label,
    required TextEditingController controller,
    required bool enabled,
    required String? Function(String?) validator,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.95),
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(2, 2)),
        ],
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: TextFormField(
        controller: controller,
        enabled: enabled,
        validator: validator,
        style: const TextStyle(fontSize: 16, color: Colors.black87),
        decoration: InputDecoration(
          labelText: label,
          border: InputBorder.none,
          labelStyle: TextStyle(color: Colors.grey[700]),
        ),
      ),
    );
  }
}
