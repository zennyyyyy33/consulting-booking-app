/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: Forgot Password Screen Page

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_fonts/google_fonts.dart';

/// Stateful widget for the Forgot Password screen
class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  _ForgotPasswordScreenState createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  // Controller to capture the user's email input
  final _emailController = TextEditingController();

  // Key to identify the form and enable validation
  final _formKey = GlobalKey<FormState>();

  // Boolean to indicate if the reset process is in progress
  bool _isLoading = false;

  /// Function to handle password reset
  Future<void> _resetPassword() async {
    // Validate the form input before proceeding
    if (!_formKey.currentState!.validate()) return;

    // Set loading state to true while processing
    setState(() => _isLoading = true);

    try {
      // Send password reset email using Firebase Authentication
      await FirebaseAuth.instance.sendPasswordResetEmail(
        email: _emailController.text.trim(),
      );

      // Show confirmation message when email is sent
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Password reset link sent to your email.'),
        ),
      );

      // Navigate back to the previous screen
      Navigator.pop(context);
    } on FirebaseAuthException catch (e) {
      // Show error message if an exception occurs
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(e.message ?? 'Error occurred')));
    } finally {
      // Set loading state back to false
      setState(() => _isLoading = false);
    }
  }

  /// Dispose of the controller to free resources
  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // App bar with custom title and background color
      appBar: AppBar(
        title: Text('Reset Password', style: GoogleFonts.montserrat()),
        backgroundColor: Colors.blueGrey.shade800,
        centerTitle: true,
      ),

      // Background with gradient
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.blueGrey.shade800,
              Colors.grey.shade600,
              Colors.grey.shade400,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),

        // Main content area wrapped in SafeArea
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Instructional text for the user
                  Text(
                    'Enter your email and we\'ll send you a reset link.',
                    style: GoogleFonts.roboto(
                      fontSize: 16,
                      color: Colors.white70,
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Email input field
                  TextFormField(
                    controller: _emailController,
                    style: const TextStyle(color: Colors.black),
                    decoration: InputDecoration(
                      labelText: 'Email',
                      labelStyle: const TextStyle(color: Colors.black87),
                      filled: true,
                      fillColor: Colors.grey[200],
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    validator:
                        (value) =>
                            value != null && value.contains('@')
                                ? null
                                : 'Enter a valid email', // Validation logic
                  ),
                  const SizedBox(height: 20),

                  // Show loading indicator or send button based on state
                  _isLoading
                      ? const Center(child: CircularProgressIndicator())
                      : ElevatedButton(
                        onPressed: _resetPassword, // Trigger reset logic
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blueGrey.shade800,
                          foregroundColor: Colors.white,
                          minimumSize: const Size(double.infinity, 50),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text('Send Reset Link'),
                      ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
