/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
///Question: Student Page
class Student {
  final String id;
  final String studentId;
  final String email;
  final String contactNumber;
  final String? profilePictureUrl;
  final String studentName;

  Student({
    required this.id,
    required this.studentId,
    required this.email,
    required this.contactNumber,
    required this.studentName,
    this.profilePictureUrl,
  });

  factory Student.fromMap(Map<String, dynamic> data, String documentId) {
    return Student(
      id: documentId,
      studentId: data['studentId'] ?? '',
      email: data['email'] ?? '',
      contactNumber: data['contactNumber'] ?? '',
      studentName: data['studentName'] ?? '',
      profilePictureUrl: data['profilePictureUrl'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'studentId': studentId,
      'email': email,
      'contactNumber': contactNumber,
      'studentName': studentName,
      'profilePictureUrl': profilePictureUrl,
    };
  }
}
