/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: Booking page
class Booking {
  final String id;
  final String studentId;
  final String adminId;
  final String lecturerName;
  final String date;
  final String time;
  final String topic;
  final String? notes;
  final String status;
  final String studentName;

  Booking({
    required this.id,
    required this.studentId,
    required this.adminId,
    required this.lecturerName,
    required this.date,
    required this.time,
    required this.topic,
    this.notes,
    required this.status,
    required this.studentName,
  });

  // Factory method to create a Booking from a Firestore document
  factory Booking.fromMap(Map<String, dynamic> data, String documentId) {
    return Booking(
      id: documentId,
      studentId: data['studentId'] ?? '',
      adminId: data['adminId'] ?? '',
      lecturerName: data['lecturerName'] ?? '',
      date: data['date'] ?? '',
      time: data['time'] ?? '',
      topic: data['topic'] ?? '',
      notes: data['notes'],
      status: data['status'] ?? 'Pending',
      studentName: data['studentName'] ?? '',
    );
  }

  // Convert the Booking instance to a Map for saving to Firestore
  Map<String, dynamic> toMap() {
    return {
      'studentId': studentId,
      'adminId': adminId,
      'lecturerName': lecturerName,
      'date': date,
      'time': time,
      'topic': topic,
      'notes': notes,
      'status': status,
      'studentName': studentName,
    };
  }
}
