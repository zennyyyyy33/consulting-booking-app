/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: Admin page
class Admin {
  final String id;
  final String email;
  final String? profilePictureUrl;
  final String lecturerName;

  Admin({
    required this.id,
    required this.email,
    required this.lecturerName,
    this.profilePictureUrl,
  });

  factory Admin.fromMap(Map<String, dynamic> data, String documentId) {
    return Admin(
      id: documentId,
      email: data['email'] ?? '',
      lecturerName: data['lecturerName'] ?? '',
      profilePictureUrl: data['profilePictureUrl'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'lecturerName': lecturerName,
      'profilePictureUrl': profilePictureUrl,
    };
  }
}
