/// Student Numbers: 221010684, 223057667, 222001658, 221025095, 222047054
/// Names: N Chauke, ML Mashele, NP Maluleke, E Tshabalala, TT Thabethe
/// Question: Main Page - Initializes Firebase and runs the Consultation Booking App

import 'package:consultation_booking_app/utils/provider.dart';
import 'package:consultation_booking_app/utils/route_manager.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:flutter/foundation.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Firebase for web with specific options
  if (kIsWeb) {
    await Firebase.initializeApp(
      options: FirebaseOptions(
        apiKey: "AIzaSyBLsv29fg9RxdFIM56fIBFVkB5eaHh7ADY",
        authDomain: "consultation-booking-app-d75dc.firebaseapp.com",
        projectId: "consultation-booking-app-d75dc",
        storageBucket: "consultation-booking-app-d75dc.firebasestorage.app",
        messagingSenderId: "491063521093",
        appId: "1:491063521093:web:604a18d8a10d1e9f45d82c",
        measurementId: "G-D773C13LC4",
      ),
    );
  } else {
    // Initialize Firebase for mobile using default options
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  }

  // Run the main application widget
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ProviderRepo(
      // Provide global state management
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Consultation Booking App.',
        theme: ThemeData(primarySwatch: Colors.blue),
        // Set the initial route to the login page
        initialRoute: RouteManager.loginPage,
        // Define route generation logic
        onGenerateRoute: RouteManager.generateRoute,
      ),
    );
  }
}
